-- 1. Write a stored procedure that accepts the month and year as inputs and prints the ordernumber, orderdate and status of the orders placed in that month. 
-- Example:  call order_status(2005, 11);

use assignment;
DROP PROCEDURE Order_status;
Delimiter //
CREATE PROCEDURE Order_status (IN year int, IN month integer)
Begin

SELECT  ordernumber, orderdate, status  from orders  where year(orderdate) = ord_year and month(orderdate) = ord_month ;

End //

call order_status(2005, 11);

-- 2. Write a stored procedure to insert a record into the cancellations table for all cancelled orders.
 DELIMITER //
CREATE PROCEDURE cancelled_order( )
  BEGIN
    DROP TABLE IF EXISTS cancellation ;
    CREATE TABLE cancellation
      (
             id int primary key auto_increment,
             customerNumber int,
             orderNumber int,
             comments text,
             FOREIGN KEY (customerNumber)
        REFERENCES customers(customerNumber)
          ON DELETE CASCADE,
             FOREIGN KEY (orderNumber)
        REFERENCES orders(orderNumber)
          ON DELETE CASCADE
       );
       INSERT INTO cancellation ( customerNumber, orderNumber, comments)
                         SELECT   customerNumber, orderNumber, comments
                  FROM orders
                    WHERE status = 'Cancelled';
       SELECT *
        FROM cancellation;
    END //
DELIMITER ;

CALL cancelled_order();
SELECT * FROM orders
 -- 3. a. Write function that takes the customernumber as input and returns the purchase_status based on the following criteria . [table:Payments]
-- if the total purchase amount for the customer is < 25000 status = Silver, amount between 25000 and 50000, status = Gold
-- if amount > 50000 Platinum

DROP FUNCTION pur_stat;
Delimiter //
CREATE FUNCTION pur_stat(
cid int
) 
RETURNS VARCHAR(20)
DETERMINISTIC
BEGIN
    DECLARE stat VARCHAR(20);
    DECLARE credit numeric;
    SET credit = (select sum(Amount) from payments where customerNumber = cid);

    IF credit > 50000 THEN
        SET stat = 'platinum';
    ELSEIF (credit >= 25000 AND 
            credit <= 50000) THEN
        SET stat = 'gold';
    ELSEIF credit < 25000 THEN
        SET stat = 'silver';
    END IF;
    RETURN (stat);
END
select 103 as customerNumber, pur_stat(103) as purchase_status;

-- 3. b. Write a query that displays customerNumber, customername and purchase_status from customers table.
Select o.status, c.customerNumber, c.customerName 
from customers  c
left join orders  o  on o.customerNumber = c.customerNumber


-- 4. Replicate the functionality of 'on delete cascade' and 'on update cascade' using triggers on movies and rentals tables. 
-- Note: Both tables - movies and rentals - don't have primary or foreign keys. Use only triggers to implement the above.

DELIMITER $$
CREATE TRIGGER trg_movies_update
AFTER DELETE ON movies
FOR EACH ROW
BEGIN
    UPDATE rentals
    SET movieid = id
    WHERE movieid = OLD.id ;
END;

DELIMITER $$
CREATE TRIGGER trg_movies_delete 
AFTER DELETE ON movies 
FOR EACH ROW 
BEGIN
    DELETE FROM  rentals
    WHERE movieid 
    NOT IN (SELECT DISTINCT id FROM movies);
END;


-- 5. Select the first name of the employee who gets the third highest salary. [table: employee]

select *
  from employee
    order by salary desc
      limit 2,1;
      
-- 6. Assign a rank to each employee  based on their salary. The person having the highest salary has rank 1. [table: employee]

SELECT fname, salary,
          @curRank := @curRank + 1 AS Order_emp
FROM  employee e, (SELECT @curRank := 0) r
ORDER BY salary desc;





