-- 1. create a database called 'assignment'

CREATE DATABASE assignment;

-- Q3. Create a table called countries with the following columns name, population, capital    

create table assignment (name varchar(50), population integer, capital varchar(25));

select * from assignment;

insert into assignment values('China', 1382, 'Beijing'),
('India', 1326, 'Delhi'),
('United States',		324, 	'Washington D.C.'),
('Indonesia',		260,	 	'Jakarta'),
('Brazil',			209,	 	'Brasilia'),
('Pakistan',	193,	 	'Islamabad'),
('Nigeria',		187,	 	'Abuja'),
('Bangladesh',		163,	 	'Dhaka'),
('Russia',			143,	 	'Moscow'),
('Japan',			126,	 	'Tokyo'),
('Philippines',		102,	 	'Manila'),
('Ethiopia',		101,	 	'Addis Ababa'),
('Vietnam', 		94,	 	'Hanoi'),
('Egypt',			93,	 	'Cairo'),
('Germany',		81, 	'Berlin'),
('Iran',		80,	 	'Tehran'),
('Turkey',		79,	 	'Ankara'),
('Congo',			79,	 	'Kinshasa'),
('France',		64, 	'Paris'),
('United Kingdom',	65,	 	'London'),
('Italy',			60,	 	'Rome'),
('South Africa',	55, 	'Pretoria'),
('Myanmar',		54,	 	'Naypyidaw');

select * from assignment;

-- b) Add a couple of countries of your choice

insert into assignment values('Korea', 300, 'Seoul'),
('Thailand', 100, 'Bangkok');

select * from assignment;

-- c) Change ‘Delhi' to ‘New Delhi'

use assignment;

select * from assignment;

UPDATE assignment
Set capital = 'New Delhi'
WHERE name = 'India';

-- 4. Rename the table countries to big_countries 

ALTER TABLE assignment rename column name to big_countries;

select * from assignment;

-- 5. Create the following tables. Use auto increment wherever applicable


CREATE TABLE STOCK
 (
 ID INT NOT NULL UNIQUE,
 PRODUCT_ID INT PRIMARY KEY,
 BALANCE_STOCK INT NOT NULL
 );
CREATE TABLE PRODUCT
 (
 PRODUCT_ID INT UNIQUE NOT NULL,
PRODUCT_NAME VARCHAR(30),
SUPPLIER_ID INT PRIMARY KEY,
CONSTRAINT PID FOREIGN KEY(PRODUCT_ID) REFERENCES STOCK(PRODUCT_ID)
);
CREATE TABLE SUPPLIERS
 (
 SUPPLIER_ID INT PRIMARY KEY,
 SUPPLIER_NAME VARCHAR(30),
 LOCATION VARCHAR(25),
 CONSTRAINT SID FOREIGN KEY(SUPPLIER_ID) REFERENCES PRODUCT(SUPPLIER_ID)
 );
SELECT * FROM Product;

-- 6. Enter some records into the three tables.
 Insert into STOCK value (10, 100, 1000);
 Insert into STOCK value (11, 101, 1000);

 Insert into PRODUCT value (10, 'PQR', 11);
 Insert into PRODUCT value (11, 'ABC', 10);
 
  Insert into SUPPLIERS value (20, 'Kalyani', 'Mumbai');
  Insert into SUPPLIERS value (10, 'Prachi', 'Pune');
 
 -- 7. Modify the supplier table to make supplier name unique and not null.
 
 ALTER table SUPPLIERS modify SUPPLIER_NAME varchar(60) unique;
 
 describe SUPPLIERS;
 
 -- 8. Modify the emp table as follows
 
 Create Table emp (
 birth_date date not null,
 first_name varchar(14) not null,
 last_name varchar(16) not null,
 gender enum('M','f') not null,
 hire_date date not null,
 salary float(8, 2) not null);

desc emp;

alter table emp add column deptno int;

alter table emp add column emp_no int;

alter table emp modify emp_no int primary key;

-- b. Set the value of deptno in the following order

-- deptno = 20 where emp_id is divisible by 2
update emp
set deptno = 20 where mod(emp_no,2) = 0;

-- deptno = 30 where emp_id is divisible by 
update emp set deptno = 30 
where mod(emp_no,3) = 0;

-- deptno = 40 where emp_id is divisible by 4
update emp set deptno = 40
 where mod(emp_no,4) = 0;
 
-- deptno = 50 where emp_id is divisible by 5
update emp set deptno = 50  
where mod(emp_no,5) = 0;

-- deptno = 10 for the remaining records.
update emp set deptno = 10
where deptno =null;

select * from emp;
-- 9. Create a unique index on the emp_id column.

ALTER TABLE emp rename column emp_no to emp_id;

CREATE  UNIQUE INDEX uiemp 
ON emp(emp_id);

Insert into emp value ('2000-12-19', 'Prachi', 'Gedam','F', '2020-1-5', 50000, 10, 100);
Insert into emp value ('2001-2-9', 'ABC', 'PQR','F', '2020-3-5', 20000, 10, 101);
Insert into emp value ('2002-1-1', 'EFG', 'XYZ','M', '2022-4-5', 5000, 10, 102);
Insert into emp value ('2003-11-10', 'LMN', 'OPQ','M', '2021-5-5', 10000, 10, 103);
Insert into emp value ('1998-3-25', 'Kalyani', 'Gedam','F', '2022-11-5', 550000, 10, 104);



-- 10. Create a view called emp_sal on the emp table by selecting the following fields in the order of highest salary to the lowest salary.
-- emp_no, first_name, last_name, salary

CREATE VIEW emp_view AS
select emp_id, first_name, last_name, salary FROM emp
ORDER BY salary DESC, salary DESC;

SELECT * FROM emp_view;


