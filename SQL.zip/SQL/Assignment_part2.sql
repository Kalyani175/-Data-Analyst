-- 1. select all employees in department 10 whose salary is greater than 3000. [table: employee]

use assignment;

select* from employee where deptno=10 and salary>3000;

-- 2. The grading of students based on the marks they have obtained is done as follows:

-- 40 to 50 -> Second Class
-- 50 to 60 -> First Class
-- 60 to 80 -> First Class
-- 80 to 100 -> Distinctions

CREATE TABLE STUDENT 
(STUDENT_ID INT (4), 
STUDENT_NAME VARCHAR (20),  
MARKS INT (3), 
PRIMARY KEY (STUDENT_ID));


INSERT INTO STUDENT VALUES (100, 'PUJA', 55); 

INSERT INTO STUDENT VALUES (101, 'SUDO', 61); 

INSERT INTO STUDENT VALUES (102, 'BHALU', 85); 

INSERT INTO STUDENT VALUES (103, 'CHETENA', 47); 

INSERT INTO STUDENT VALUES (104, 'MOMO', 91);

SELECT * FROM STUDENT;


SELECT STUDENT_ID, STUDENT_NAME, MARKS,
CASE WHEN marks BETWEEN 81 AND 100 then 'Distinction' 
            WHEN marks BETWEEN 51 AND 80 then 'First Class' 
            WHEN marks BETWEEN 40 AND 50 then 'Second class'  
            ELSE 'No Grade Available' 
        END Grade
     FROM STUDENT;

-- a. How many students have graduated with first class?

Select count(*) res from STUDENT where marks between 50 and 80;

-- b. How many students have obtained distinction? [table: students]

Select count(*) res from STUDENT where marks between 81 and 100;

-- 3. Get a list of city names from station with even ID numbers only. Exclude duplicates from your answer.[table: station]

  SELECT DISTINCT CITY FROM STATION WHERE MOD(STATION.ID,2)=0 ORDER BY CITY;
  
  SELECT * FROM CITY;
  
  -- 4. Find the difference between the total number of city entries in the table and the number of distinct city entries in the table. In other words, if N is the number of city entries in station, and N1 is the number of distinct city names in station, write a query to find the value of N-N1 from station.
-- [table: station]

SELECT (COUNT(city) - COUNT(DISTINCT city)) AS difference
    FROM station;

-- 5. a. Query the list of CITY names starting with vowels (i.e., a, e, i, o, or u) from STATION. Your result cannot contain duplicates. [Hint: Use RIGHT() / LEFT() methods ]

SELECT DISTINCT city
    FROM station
    WHERE UPPER(LEFT(city, 1)) IN ('A', 'E', 'I', 'O', 'U');
    
-- 5. b. Query the list of CITY names from STATION which have vowels (i.e., a, e, i, o, and u) as both their first and last characters. Your result cannot contain duplicates.

SELECT DISTINCT city
    FROM station
    WHERE UPPER(LEFT(city, 1)) IN ('A', 'E', 'I', 'O', 'U')
                     AND UPPER(RIGHT(city, 1)) IN ('A', 'E', 'I', 'O', 'U');

-- 5. c. Query the list of CITY names from STATION that do not start with vowels. Your result cannot contain duplicates.

SELECT DISTINCT city
    FROM station
    WHERE UPPER(LEFT(city, 1)) NOT IN ('A', 'E', 'I', 'O', 'U');
                     
-- 5. d. Query the list of CITY names from STATION that either do not start with vowels or do not end with vowels. Your result cannot contain duplicates. [table: station]

SELECT DISTINCT city
    FROM station
    WHERE UPPER(LEFT(city, 1)) NOT IN ('A', 'E', 'I', 'O', 'U')
                     AND UPPER(RIGHT(city, 1)) NOT IN ('A', 'E', 'I', 'O', 'U');

-- 6. Write a query that prints a list of employee names having a salary greater than $2000 per month who have been employed for less than 36 months.
-- Sort your result by descending order of salary. [table: emp]
select * from emp where 
salary>2000 AND hire_date >= DATE_SUB(CURRENT_DATE, INTERVAL 36 MONTH)
order by salary DESC ;


-- 7. How much money does the company spend every month on salaries for each department? [table: employee]

SELECT deptno, SUM(salary) as total_salary 
FROM employee
GROUP BY deptno;

-- 8. How many cities in the CITY table have a Population larger than 100000. [table: city]
select distinct count(*)  from city  where population >= '100000';

-- 9. What is the total population of California? [table: city]
select  sum(population) as Total_Population  from city where district='California';

-- 10. What is the average population of the districts in each country? [table: city]

select countrycode, avg(population)
from city
where countrycode in('JPN','USA','NLD')
group by countrycode;

-- 11. Find the ordernumber, status, customernumber, customername and comments for all orders that are ‘Disputed=  [table: orders, customers]

Select o.orderNumber, o.status, o.customerNumber, c.customerName , o.comments
from orders  o 
left join customers  c on o.customerNumber = c.customerNumber
where status='Disputed'
