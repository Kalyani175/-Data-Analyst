# 1.Try to write a code for printing sequence of numbers from 1 to 50 with the differences of 3, 5, 10 

seq(1,50)

seq(from = 1, to = 50, by = 3)

seq(from = 1, to = 50, by = 5)

seq(from = 1, to = 50, by = 10)



# 2. What are the different data objects in R? and write syntax and example for each and every object


#1 Vectors

# Create a vector.
apple <- c('red','green',"yellow")
print(apple)

# Get the class of the vector.
print(class(apple))


#2 List

# Create a list.
list1 <- list(c(2,5,3),21.3,sin)

# Print the list.
print(list1)


#3 Matrices

# Create a matrix.
M = matrix( c('a','a','b','c','b','a'), nrow = 2, ncol = 3, byrow = TRUE)
print(M)


#4 Arrays

# Create an array.
a <- array(c('green','yellow'),dim = c(3,3,2))
print(a)


#4 Factors

# Create a vector.
apple_colors <- c('green','green','yellow','red','red','red','green')

# Create a factor object.
factor_apple <- factor(apple_colors)

# Print the factor.
print(factor_apple)
print(nlevels(factor_apple))


#5 Data Frames

# Create the data frame.
BMI <- 	data.frame(
  gender = c("Male", "Male","Female"), 
  height = c(152, 171.5, 165), 
  weight = c(81,93, 78),
  Age = c(42,38,26)
)
print(BMI)


#3. Create Data frame with 3 columns and 5 rows and write a code to fetch and delete row and a column using index and add new column and row to the existed data frame


name = c('Dima', 'Katherine', 'James', 'Emily', 'Michael')
score = c(12.5, 9, 16.5, 12, 9)
attempts = c(1, 3, 2, 3, 2)
df = data.frame(name, score, attempts)  
print(df)


#delete row

df1 = df[-c(2),]
df1

# Remove Columns by Index
 df2 = df[,-2]
 df2
 
 
 #define new column to add
  new = c(5, 9, 6, 2, 1)
 
    #add column called 'new'
   df$new = new
 df

 # adding a new row 
 New_df = rbind(df, c("Tall", 25, 1, 8))
 
 New_df


#4.Write nested if else statements to print whether the given number is negative, positive or Zero 
 
 num = 10  
 if(num<0){  
   print("Num is NEGATIVE")  
 }else if(num>0){  
   print("Num is POSITIVE")  
 }else{  
   print("Num is ZERO")  
 }  



#5.write a program to input any value and check whether it is character, numeric or special character
 

 ch = readline("Please Enter Your Own Character : ")
 
 if(ch.isdigit()){
   print("The Given Character ", ch, "is a Digit")
 elif(ch.isalpha())
   print("The Given Character ", ch, "is an Alphabet")
 }else{
   print("The Given Character ", ch, "is a Special Character")
 }
 
#6 write difference between break and next also write examples for both 
 
 #  break statement in For-loop
 

 
 for (val in no)
 {
   if (val == 5)
   {
     print(paste("Coming out from for loop Where i = ", val))
     break
   }
   print(paste("Values are: ", val))
 }
 
 #  Next Statement in For-loop
 

 
 for (val in no)
 {
   if (val == 6)
   {
     print(paste("Skipping for loop Where i = ", val))
     next
   }
   print(paste("Values are: ", val))
 }
 
#7.write a program to print a given vector in reverse format  
 

 
 x= c(1,5.6,3,10,3.5,5)
 print("Original vector-1:")
 print(x)
 rv = rev(x)
 print("The said vector in reverse order:")
 print(rv)


 
#8.write a program to get the mode value of the given vector (‘a’,’b’,’c’,’t’,’a’,’c’,’r’,’a’,’c’,’t’,’z’,’r’,’v’,’t’,’u’,’e’,’t’)

 # Create the function.
 getmode = function(v) {
   uniqv = unique(v)
   uniqv[which.max(tabulate(match(v, uniqv)))]
 }
 

 # Create the vector with characters.
 charv <- c("a","b","c","t","a","c","r","a","c","t","z","r","v","t","u","e","t")
 
 # Calculate the mode using the user function.
 result = getmode(charv)
 print(result)

 
#9.Write a function to filter only data belongs to ‘setosa’ in species of Iris dataset.( using dplyr package) 

install.packages("dplyr")

#To load dplyr package
library("dplyr")
#To load datasets package
library("datasets")
#To load iris dataset
data(iris)
summary(iris)

#To select the first 3 rows with Species as setosa
filtered <- filter(iris, Species == "setosa" )
head(filtered,3)



#10.Create a new column for iris dataset with the name of Means_of_obs, which contains mean value of each row.( using dplyr package)

### Select columns -----------------------
select(iris, Sepal.Length, Sepal.Width)

iris %>% 
  group_by(Species) %>% 
  summarise(Mean.Petal.Length = mean(Petal.Length),
            n.Petals = length(Petal.Length),
            sd.Petal.Length = sd(Petal.Length),
            SE.Petal.Length = sd(Petal.Length) / sqrt(length(Petal.Length))) %>% 
  arrange(-Mean.Petal.Length)




#11.Filter data for the “versicolor” and get only ‘sepel_length’ and Sepel _width’ columns.( using dplyr package)


data(iris) # load the iris data
iris2 = tibble::as_tibble(iris)
print(iris2)


iris2 = tibble::as_tibble(iris)
filter(iris2, Species == 'versicolor') 


#12.create below plots for the mtcars also write your inferences for each and every plot (use ggplot package) Use Different ( Size , Colour )

#installing package
install.packages("ggplot2")
library(ggplot2)


# Creating a histogram

# Considering the iris data.

ggplot(data  = iris, aes( x = Sepal.Length)) + geom_histogram( )


# Creating a Bar Graph

p = ggplot(mpg, aes(x= class)) + geom_bar()
p = p + labs(title = "Number of Cars in each type", x = "Type of car", y = "Number of cars")
p + geom_text(stat='count', aes(label=..count..), vjust=-0.25)


# Creating a Box plot

mtcars$cyl = factor(mtcars$cyl)
ggplot(mtcars, aes(x=cyl, y=disp)) + geom_boxplot()


# Creating a scatter plot 
ggplot(data = iris, aes( x = Sepal.Length, y = Sepal.Width,shape = Species, color = Species)) + geom_point()

# Creating a line graph
ggplot(data = iris, aes( x = Sepal.Length, y = Sepal.Width)) +geom_smooth()


